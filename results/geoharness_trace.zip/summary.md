# GeoAgent trace summary

- session: 37d73f5ed8384221ab1f9d29ad5ae875  profile: full  coverage: ledger-only
- records: 7 (chain head seq 6)
- bundle: geoagent-trace/0.1, server 0.1.0

## wuhan_lake_lst

### Inputs
- built: kind=vector, crs=EPSG:32649
- lakes: kind=vector, crs=EPSG:32649
- lst: kind=raster, crs=EPSG:32649

### Final DAG (81c843f45c7a)
- b150: buffer
- b450: buffer
- b600: buffer
- b900: buffer
- built: source built
- far_ring: overlay
- far_stats: zonal_stats
- far_zones: clip_vector
- lakes: source lakes
- lst: source lst
- near_ring: overlay
- near_stats: zonal_stats
- near_zones: clip_vector

### Verification and repairs
- seq 5 verify_dag: PASS

### Execution
- run 58a57d4dbf6640ed8e3b99481a83fb7a: ok; L4 PASS; 4 output(s)
