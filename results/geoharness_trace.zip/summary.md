# GeoAgent trace summary

- session: 808db33037134c10b39e139052ec2f02  profile: full  coverage: ledger-only
- records: 7 (chain head seq 6)
- bundle: geoagent-trace/0.1, server 0.1.0

## wuhan_lake_lst

### Inputs
- built_up: kind=vector, crs=EPSG:32649
- lakes: kind=vector, crs=EPSG:32649
- lst: kind=raster, crs=EPSG:32649

### Final DAG (94eff7f0f1db)
- b150: buffer
- b450: buffer
- b600: buffer
- b900: buffer
- far_ring: overlay
- far_stats: zonal_stats
- far_zones: clip_vector
- lake_features: source lakes
- near_ring: overlay
- near_stats: zonal_stats
- near_zones: clip_vector
- temperature: source lst
- urban_mask: source built_up

### Verification and repairs
- seq 5 verify_dag: PASS

### Execution
- run 68ee2da1307d4e67a93d60377f070cf1: ok; L4 PASS; 4 output(s)
